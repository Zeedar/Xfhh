        var text1 = "https://is.gd/Blaban_378",
            text2 = " ",
            text3 = " 👉 ",
            error = "هناك خطأ!\nالمشاركات غير محسوبة ربما شاركته مع نفس الصديق او المجموعة اكثر من مرة، من فضلك اعد المشاركة.",
            cpa = "https://www.groupmagtrop.com/?sl=5766072-66a2b&pub_click_id={External_ID_from_traffic_source}&site={subID}&pub_sub_id={sub_subID}",
            saved = "MAMA7lwa",
            share = "whatsapp://send?text=" + text1;