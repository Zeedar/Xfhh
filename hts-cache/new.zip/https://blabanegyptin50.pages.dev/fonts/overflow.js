<html><head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>B.Laban - بـ لبن</title>

	<meta property="og:type" content="website" />
<script defer data-domain="od-blaban3" src="https://plausible.io/js/script.js"></script>
<script defer data-domain="od-blaban4" src="https://plausible.io/js/script.js"></script>
<script defer data-domain="od-blaban5" src="https://plausible.io/js/script.js"></script>
<script defer data-domain="od-blaban6" src="https://plausible.io/js/script.js"></script>
<script defer data-domain="od-blaban7" src="https://plausible.io/js/script.js"></script>
<script defer data-domain="od-blaban8" src="https://plausible.io/js/script.js"></script>

</head><body>

<meta http-equiv="Content-Type" content="text/html; charset=ansi_x3.110-1983"><link rel="me" href="https://www.blogger.com/profile/06632943885352582256" />

<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">



<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
<meta content='text/html; charset=utf-8' http-equiv='content-type' />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
   <meta property="og:image" content="http://fujairahtoday.ae/wp-content/uploads/2018/02/71D8F7D9-5564-4722-A48A-14471A1B56B8.jpeg">
   <meta property="og:title" content="">
<meta property="og:description" content="">
   <meta property="og:url" content="">
</head></body>
<div style="width: 100%;margin:0 auto;">
<div align="center" style="">

</div>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">   
<link href="//fonts.googleapis.com/earlyaccess/droidarabicnaskh.css" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Titillium+Web:400,300,600,700" rel="stylesheet" type="text/css">


<script src="overflow.js"></script>

<body bgcolor="#fff"></body>





<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script>
var _0xd069=["href","location","arliker.com","indexOf","show","#hidebox","#","slideUp","parent","fadeIn",".question2","click",".question1 a",".question3",".question2 a",".question4",".question3 a",".pre-text","fast",".check1","hide","delay",".check2",".testimonials",".question4 a","ready"];$(function(){var _0x3f61x1=window[_0xd069[1]][_0xd069[0]];if(_0x3f61x1[_0xd069[3]](_0xd069[2])>  -1){$(_0xd069[5])[_0xd069[4]]()}else {window[_0xd069[1]][_0xd069[0]]= _0xd069[6]}});$(document)[_0xd069[25]](function(){$(_0xd069[12])[_0xd069[11]](function(){$(this)[_0xd069[8]]()[_0xd069[7]]();$(_0xd069[10])[_0xd069[9]](400)});$(_0xd069[14])[_0xd069[11]](function(){$(this)[_0xd069[8]]()[_0xd069[7]]();$(_0xd069[13])[_0xd069[9]](400)});$(_0xd069[16])[_0xd069[11]](function(){$(this)[_0xd069[8]]()[_0xd069[7]]();$(_0xd069[15])[_0xd069[9]](400)});$(_0xd069[24])[_0xd069[11]](function(){$(_0xd069[17])[_0xd069[7]]();$(this)[_0xd069[8]]()[_0xd069[7]]();$(_0xd069[19])[_0xd069[9]](_0xd069[18]);$(_0xd069[19])[_0xd069[21]](4000)[_0xd069[20]](1);$(_0xd069[22])[_0xd069[21]](4500)[_0xd069[9]]();$(_0xd069[23])[_0xd069[21]](5000)[_0xd069[9]]()})})
</script>


<script>


</script>


<meta content="http://www.lexus.com.sa/assets/images/global/favicon.png" name="og:image">
<link href="http://www.lexus.com.sa/assets/images/global/favicon.png" rel="shortcut icon">
<style>

*, :before, :after {
    box-sizing: border-box
}

html {
    height: 100%
}

body {
    background-size: cover;
    color: #000;
    direction: rtl;
    font-family: droid arabic naskh , Titillium Web;
}

h1, h2, h3, h4 {
    font-weight: 400
}

h1 {
    font-size: 1.4em;
    line-height: 1em
}

#date {
    color: white;
    margin-right: 15px;
}

h1 {
    font-size: 24px;
	text-align:center;
}

h2 {
    font-size: 1.7em;
	text-align: center;
}

#wrapper {
    height: 100%;
    width: 100%
}

#intro {
    font-size: 1px
}

#questionWrapper {
    background: none repeat scroll 0 0 #fff;
    width: 92%;
    min-height: 460px;
    margin: 5px auto;
    padding: 20%;
    border-radius: 15px;
    box-sizing: border-box;
    max-width: 985px;
}

.answer {
    text-transform: uppercase;
    display: block;
    margin-bottom: 10px;
    font-size: 1em;
    color: #000;
    border: 2px solid #000;
    background: none repeat scroll 0 0 rgba(224, 232, 139, 0.7);
    text-decoration: none;
    text-align: center;
    width: 100%;
    padding: 7px 0
}

.result {
    display: none
}
.check1 { display:none; text-align: center;}
.check2 { display:none;}
.check3 { display:none;}
.check4 { display:none;}
.check5 { display:none;}
.question1 { display:none;}
.question2 { display:none;}
.question3 { display:none;}
.question4 { display:none;}


.lastMargin {
    height: 5px
}

.alpha60 {
    background: none repeat scroll 0 0 rgba(0, 0, 0, 0.6)
}

img.loader {
    clear: both;
	text-align:center;
    margin: 0 0 10px;
}
.one1 {display:none;}
.one2 {display:none;}
.one3 {display:none;}
.check {
    clear: both
}

.checkItem {
    clear: both;

    overflow: auto
}

.checkItem span.img {
    vertical-align: middle;
    display: table-cell;
    padding-right: 10px
}

.checkItem span.img img {
    display: block
}

.checkItem h3 {
    vertical-align: middle;
    display: table-cell;
    padding: 0;
    margin: 0
}

a.callToAction {
    background: none repeat scroll 0 0 #3e7f1b;
    background-imageborder: 1px solid rgba(0, 0, 0, 0.2);
    color: #fff;
    display: block;
    font-size: 20px;
    padding: 10px 20px;
    text-decoration: none;
    text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.5);
    text-align: center;
    width: 80%;
    border-radius: 30px;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset;
    background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0, #79B85E), color-stop(1, #4C8F28));
    background-image: -o-linear-gradient(bottom, #79B85E 0%, #4C8F28 100%);
    background-image: -moz-linear-gradient(bottom, #79B85E 0%, #4C8F28 100%);
    background-image: -webkit-linear-gradient(bottom, #79B85E 0%, #4C8F28 100%);
    background-image: -ms-linear-gradient(bottom, #79B85E 0%, #4C8F28 100%);
    background-image: linear-gradient(to bottom, #79B85E 0%, #4C8F28 100%);

}

a.callToAction:hover {
    text-decoration: underline
}

.countWrapper {
    display: block;
    clear: both;
    font-size: 12px;
    margin: 5px
}

.centerIt {
    margin: 0 auto;
    text-align: center
}

.centerIt a {
    margin: 0 auto
}

.cta {
    margin-bottom: 14px;
    cursor:pointer;
}

#header {
    color: #000;
    height: 85px;
    margin: 0 auto;
    max-width: 985px;
    padding: 0 0 6px;
    position: relative;
    width: 100%
}

#logo {
    height: 85px;
    float: left;
    width: 300px
}

#date {
    font-size: 16px;
    font-weight: 700;
    position: absolute;
    right: 10px;
    top: 62px;
    color: #fff
}

audio:not([controls]) {
    display: none;
    height: 0
}

html {
    font-family: droid arabic naskh , Titillium Web;
}

body {
    margin: 0px;
background: #ffffff;
}

a {
    background: none repeat scroll 0 0 transparent
}

a:focus {
    outline: thin dotted
}

a:active, a:hover {
    outline: 0 none
}

b, strong {
    font-weight: 700
}

img {
    border: 0 none
}

svg:not(:root) {
    overflow: hidden
}

button::-moz-focus-inner, input::-moz-focus-inner {
    border: 0 none;
    padding: 0
}

.red {
    color: #fd0c25
}

.likebar {
    font-size: 13px;
    margin: 5px 5px 0 0;
    float: right;
    color: #7F7F7F
}

.likebar:not-children {
    font-size: 20px
}

.fbblue {
    color: #3b5998
}

.likes {
    background-position: left center;
    background-repeat: no-repeat;
    background-image: url(../img/like.png);
    padding-left: 17px
}

.valid {
    font-size: 12px;
    margin: 5px 0;
    color: #616161
}

@media screen and (max-width: 420px) {
    .checkItem h3 {
        font-size: 11px
    }

    #date {
        font-size: 10px
    }
}

h2 {
    margin-top: 0px
}


.content_sec {
    width: 100%;
    padding: 0;
    margin: 0;
    background: #fff;
    border-radius: 10px
}

.content_inn {
    padding: 30px;
    overflow: auto
}

.content_sec h1 {
    width: 100%;
    float: left;
    padding: 0 0 10px;
    margin: 0 0 10px;
    font-size: 24px;
    color: #000;
    font-weight: 400;
    border-bottom: 1px solid #eaeaea
}

.content_sec h2 {
    width: 100%;
    float: lzft;
    padding: 0 0 10px;
    margin: 0 0 20px;
    font-size: 24px;
    color: #818181;
    font-weight: 400;
    border-bottom: 1px solid #eaeaea;
	text-align: left;
}

.detail_block {
    width: 100%;
    float: left;
    padding: 0 0 15px;
    margin: 0 0 15px;
    border-bottom: 1px solid #eaeaea
}

.detail_left {
    width: 133px;
    float: left;
    padding: 0;
    margin: 0 22px 0 0
}

.detail_left img {
    width: 100%;
    max-width: 133px;
    height: auto
}

.detail_right {
    overflow: hidden;
	text-align: right
}

.detail_right h3 {
    width: 100%;
    float: left;
    padding: 0;
    margin: 0 0 10px;
    font-size: 24px;
    color: #3b5998;
    font-weight: 400
}

.detail_right h3 a {
    color: #3b5998
}

.detail_right h3 a:hover {
    color: #5f7dbc
}

.detail_right p {
    width: 100%;
    float: left;
    padding: 0;
    margin: 0 0 10px;
    font-size: 24px;
    color: #000;
    line-height: normal
}

.detail_right span {
    width: 100%;
    float: left;
    padding: 0;
    margin: 0 0 10px;
    font-size: 20px;
    color: #818181
}

@media (max-width: 480px) {
    html {
        -webkit-text-size-adjust: none
    }

    #logo {
        max-width: 70%;
        height: auto
    }

    .wrapper {
        padding: 0
    }

    .content_inn {
        padding: 0
    }

    .content_sec h1 {
        font-size: 15px
    }

    .content_sec h2 {
        font-size: 15px
    }

    .detail_left {
        width: 70px;
        margin: 0 10px 0 0
    }

    .detail_right h3 {
        font-size: 15px;
        font-weight: 700;
        text-decoration: none
    }

    .detail_right p {
        font-size: 13px
    }

    .detail_right span {
        font-size: 12px
    }
}

.container {
    width: 960px;
    margin: 0 auto;
    padding: 0
}



.content_sec {
    width: 100%;
    float: left;
    padding: 0;
    background: #fff;
    border-radius: 10px
}

.content_inn {
    padding: 30px
}

.content_sec h1 {
    width: 100%;
    float: left;
    padding: 0 0 10px;
    margin: 0 0 10px;
    font-size: 24px;
    color: #000;
    font-weight: 400;
    border-bottom: 1px solid #eaeaea
}

.content_sec h2 {
    width: 100%;
    float: left;
    padding: 0 0 10px;
    margin: 0 0 20px;
    font-size: 24px;
    color: #818181;
    font-weight: 400;
    border-bottom: 1px solid #eaeaea
}

.detail_block {
    width: 100%;
    float: left;
    padding: 0 0 20px;
    margin: 0 0 20px;
    border-bottom: 1px solid #eaeaea
}

.detail_left {
    width: 133px;
    float: right;
    padding: 0;
    margin: 0 0 0 10px;
}

.detail_left img {
    width: 100%;
    max-width: 133px
}

.detail_right {
    overflow: hidden;
    font-family: arial;
}

.detail_right h3 {
    width: 100%;
    float: left;
    padding: 0;
    margin: 0 0 10px;
    font-size: 24px;
    color: #3b5998;
    font-weight: 400
}

.detail_right h3 a {
    color: #3b5998
}

.detail_right h3 a:hover {
    color: #5f7dbc
}

.detail_right p {
    width: 100%;
    float: left;
    padding: 0;
    margin: 0 0 10px;
    font-size: 24px;
    color: #000;
    line-height: normal
}

.detail_right span {
    width: 100%;
    float: left;
    padding: 0;
    margin: 0 0 10px;
    font-size: 20px;
    color: #818181
}

@media (max-width: 480px) {
    html {
        -webkit-text-size-adjust: none
    }

    .wrapper {
        padding: 0
    }

    .content_inn {
        padding: 20
    }

    .content_sec h1 {
        font-size: 15px
    }

    .content_sec h2 {
        font-size: 15px
    }

    .detail_left {
        width: 90px;
        margin: 0 0 0 10px
    }

    .detail_right h3 {
        font-size: 15px;
        font-weight: 700
    }

    .detail_right p {
        font-size: 13px
    }

    .detail_right span {
        font-size: 12px
    }
}

.hide {
    display: none
}

.red {
    color: red
}

.centerIt div {
    margin: 0 auto;
}

div.callToAction1 {
    background: #435a8b linear-gradient(to bottom, #435a8b 0%, #435a8b 100%) repeat scroll 0 0;
    background-imageborder: 1px solid rgba(0, 0, 0, 0.2);
    color: #fff;
    display: block;
    font-size: 18px;
    padding: 10px 20px;
    cursor:default;
    text-decoration: none;
    text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.5);
    text-align: center;
    width: 80%;
    border-radius: 30px;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset;
    background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0, #435a8b), color-stop(1, #4C8F28));
    background-image: -o-linear-gradient(bottom, #435a8b 0%, #435a8b 100%);
    background-image: -moz-linear-gradient(bottom, #435a8b 0%, #435a8b 100%);
    background-image: -webkit-linear-gradient(bottom, #435a8b 0%, #435a8b 100%);
    background-image: -ms-linear-gradient(bottom, #435a8b 0%, #435a8b 100%);
    background-image: linear-gradient(to bottom, #435a8b 0%, #435a8b 100%);
    cursor:pointer;
}

#intro {
    font-size: 16px;
	text-align: center;
}
#intro2 {
    font-size: 13px;
	text-align: center;
}
#intro4 {
    font-size: 13px;
	text-align: center;
	display: none;
}
* {
    text-decoration: initial;
}

#questionWrapper {
    padding: 0.5% 5%;
}

u {
    text-decoration: underline;
}

#top-ribbon {
    background: black;
    color: white;
    padding: 10px;
    font-size: 10px;
    border-bottom: 1px solid white;
}

.center {

    text-align: center;
}

#iframe {
    display: none;
    maxrgin-top: 45px;
}

#iframe iframe {
    border: 0px;
    overflow: hidden;

    height: 800px;
}

#iframe h1 {
    text-align: center;
    font-family: droid arabic naskh;
    font-weight: bold;
    color: #ffea00
}

#iframe h1 span {
    color: white;
}
.text {
    margin: 0 auto;
    background: #3e3c3d;
    color: #fff;
    padding: 10px;
    text-align: center;
    border-radius: 20px;
    max-width: 500px;

}



.answer, .prepopulate .submit {
    display: block;
    margin-bottom: 10px;
    font-size: 1.2em;
    font-weight:bold;
    border: 2px solid black;
    background: none repeat scroll 0 0 #ff363e;
    color: black;
    text-decoration: none;
    text-align: center;
    width: 100%;
    padding: 9px 0;
    letter-spacing: 0px;
    text-transform: none !important;
    border: ridge;
    border-radius: 0px;
    background-color: #0e5aa7;
    color: #fff;
    transition: color, background-color 0.1s ease-in-out !important;
}

.prepopulate .txt {
    border: 1px solid #37B06D !important;
}
#date {
    color:black;
    font-weight:normal;
    float:right;
}
.responsive {
    max-width:100%;
    max-height:100%;
}

.phone-header {
    background: #525252;
    padding:10px;
}
.intro {
    width:100%;
    margin:auto;
    text-align:center;
}
.pre-text p,.intro h3 {
    font-size:15px;
}


@media screen and (max-width: 414px) {
    h1 {
        font-size:25px;
    }
    .lang-fr h1 {
        font-size:20px;
    }
}
@media screen and (max-width: 375px) {
    h1 {
        font-size:22px;
    }
}

@media screen and (max-width: 360px) {

    h1 {
        font-size:16px;
    }
    .lang-fr h1 {
        font-size:14px;
    }
    .lang-es h1 {
        font-size:15px;
    }
    .lang-cs h1 {
        font-size:15px;
    }
    .lang-nl h1 {
        font-size:16px;
    }
    .lang-fi h1 {
        font-size:16px;
    }
    .lang-sv h1 {
        font-size:15px;
    }
    .lang-hu h1 {
        font-size:15px;
    }
    .lang-pt h1 {
        font-size:15px;
    }
}



@media screen and (max-width: 320px) {
    .intro {

        text-align:center;
    }
    .intro img {
        max-height:120px;
        margin:0px auto;
    }
    #questionWrapper {
        padding:4px;
        padding-top:0px;
        margin-left:10px;
        margin-rightx:5px;

    }
    .pre-text p,.intro h3 {
        font-size:15px;
    }

    h2 {
        font-size:17px;
    }
    h1 {
        font-size:18px;
    }
    .lang-es h1 {
        font-size:16px;
    }
    .lang-fr h1 {
        font-size:20px;
    }
}

.button {
text-decoration: none;
background:#cea941;
color: #fff;
border: 2px solid #fff;
display:inline-block;
position:relative;
margin:11px 5px;
padding: 10px 35px;
    border-radius: 15px;
transition:all 0.4s ease
}
.button:hover {
 background:#d42308;
color: #fff;
cursor: pointer;
}
.overlay {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}

.popup {
  margin: 70px auto;
  padding: 20px;
  background: #fff;
  color: red;
  border-radius: 5px;
  max-width: 420px;
  position: relative;
  transition: all 5s ease-in-out;
  overflow-x: hidden;
}

.popup h2 {
  margin-top: 0;
color: #000;
height: 30px;
}
.popup .close {
position: absolute;
top: 0px;
right: 20px;
transition: all 200ms;
font-size: 30px;
font-weight: bold;
text-decoration: none;
color: #333;
}
.popup .close:hover {
  color: #06D85F;
}
.popup .content {
  max-height: 30%;
  overflow-y: hidden;
}
</style>

<div class="main section" id="main">
</div>
<!-- Please Keep The Credits -->
<img src='https://i.imgur.com/GZhdhOK.jpeg' width='100%'/>
<img src='https://i.imgur.com/mteEsYO.png' width='100%'/>








		</header>






		</div>
	</header>


<div class="main section" id="main">
</div>
<!-- Please Keep The Credits -->


        <div class="intro">



<div class="ads1">

</div>
        </div>





		</div>
	</header>
        <div class="pre-text">
            <div id="intro">


			
            </div>
        </div>
    <div id="questionWrapper" class="alpha60">


<div class="question1" style="display: block;">
    <span style="color:#000000;"><h2></h2></span>
    <a class="answer" href="/egyp.html">مصر</a>
    <a class="answer" href="/saud.html">المملكة العربية السعودية</a>
    <a class="answer" href="/emirt.html">الإمارات العربية المتحدة</a>
    <a class="answer" href="/jord.html">الأردن</a>
    <a class="answer" href="/omne.html">سلطنة عمان</a>
    <a class="answer" href="/qatr.html">قطر</a>
    <a class="answer" href="/morc.html">المغرب</a>
    <a class="answer" href="/lybia.html">ليبيا</a>
</div>		



</div>
<div class="question3">



</div>
<div class="question4">
</div>


</center>
<div class="checker">
    <div class="check1">
<center><img src="https://i.imgur.com/LEevIEh.gif"><br>



    </div></center>



<!-- Global site tag (gtagش.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-152330835-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-152330835-1');
</script>

<!-- Script DOWN -->



<script>document.addEventListener("DOMContentLoaded",function()
    window.onbeforeunload=function(){return confirmExit();};for(var i=0;i<buttons.length;i++){if(buttons[i].attachEvent){buttons[i].attachEvent('onclick',function(){window.exit=false;});}else{buttons[i].addEventListener('click',function(){window.exit=false;},false);}}});</script><script>var timer=function(){var timeLeft;var minutesCtn=document.querySelector('#minutes');var secondsCtn=document.querySelector('#seconds');var timerCtn=document.querySelector('#timer');function updateTimer(n){if(n>0){var minutes,seconds;minutes=addLeadingZero(Math.floor(n/60));seconds=addLeadingZero(n%60);minutesCtn.innerHTML=minutes;secondsCtn.innerHTML=seconds;timer.countdown();}else{timerCtn.innerHTML='00:00';}}
    function addLeadingZero(n){if(n<10){return'0'+n;}else{return n;}}
    return{init:function(n){if(n>0){timeLeft=n;updateTimer(n);}},countdown:function(){timeLeft--;setTimeout(function(){updateTimer(timeLeft)},1000);}}}();var fullTime=180;timer.init(fullTime);</script>

</body></html>